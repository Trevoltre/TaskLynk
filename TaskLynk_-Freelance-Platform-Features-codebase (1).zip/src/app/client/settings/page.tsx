"use client";

import SettingsPage from "@/app/settings/page";

export default function ClientSettingsPage() {
  return <SettingsPage />;
}
